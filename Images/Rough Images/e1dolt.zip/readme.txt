button text: Start Game
primary color: 000000
gradient color: 330099
width (pixels): 336
height (pixels): 100
corner radius (pixels): 15
text height (points): 34
text color: ffffff
background color: clear
font name: DejaVuSans
rollover primary color: ffcc00
rollover gradient color: 6666ff
rollover text color: 000000
quality: 3
image location: none
image height (pixels): 12
image name: 
image foreground color determination: auto
image foreground color: 000000
image transparent color determination: auto
image transparent color: ffffff
url: http://www.glassybuttons.com/glassy.php?button_text=Start+Game&amp;color=000000&amp;grcolor=330099&amp;width=336&amp;height=100&amp;radius=15&amp;theight=34&amp;tcolor=ffffff&amp;bkcolor=clear&amp;fname=DejaVuSans&amp;rcolor=ffcc00&amp;rgrcolor=6666ff&amp;rtcolor=000000&amp;imglocate=none&amp;imgheight=12&amp;imgname=&amp;imgfore=auto&amp;imgforecolor=000000&amp;imgtran=auto&amp;imgtrancolor=ffffff&amp;quality=3&amp;fromhere=1
